/**
 * Created by Mike on 20/09/2017.
 */
import React, { Component } from 'react';


export default
class DesktopCar extends Component {
    render() {

        return (
            <li>

            </li>
        )
    }
}
