var app = angular.module('myApp', ['ngRoute'])
    .config(['$routeProvider', function($routeProvider){
        $routeProvider.
            when('/main',{
                templateUrl: 'desktop.html',
                controller:'mainController'
            }).
            when('/tablet',{
                templateUrl: 'tablet.html',
                controller:'mainController'
            }).
            when('/mobile',{
                templateUrl: 'mobile.html',
                controller:'mainController'
            }).
            otherwise({redirectTo:'/main'})
    }])
    .controller('mainController',['$scope', '$http',function($scope, $http ){
        $scope.vehicleObjects = [];
        $http.get('http://localhost:9988/api/vehicle').then(function(response){
            //console.log(response.data);
            $scope.vehicles = response.data.vehicles;
            $scope.createVehicleObjects($scope.vehicles);
        });

        $scope.createVehicleObjects = function(cars) {
            for (i = 0; i < cars.length; i++) {
                var carMedia = cars[i]['media'];
                for (j = 0; j < carMedia.length; j++) {
                    $scope.getVehicle(cars[i]['id'], carMedia[j]['url'], cars[i]['modelYear']);

                    console.log(cars[i]['media']);
                }
            }
        }

        $scope.getVehicle = function(id, imageUrl, trim){
            $http.get('http://localhost:9988/api/vehicle/'+id).then(function(response){
                console.log($scope.vehicleObjects);
                var obj = response.data;
                obj.image = "/MediaQueryTest/app"+imageUrl;
                obj.name = id+' '+trim;
                $scope.vehicleObjects.push(response.data);
                //return $scope.vehicleObj;
            });
        }
    }]);

